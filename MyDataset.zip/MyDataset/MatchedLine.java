public class MatchedLine {
    public int oldLineNumber;
    public int newLineNumber;

    public MatchedLine(int oldLineNumber, int newLineNumber) {
        this.oldLineNumber = oldLineNumber;
        this.newLineNumber = newLineNumber;
    }
}
