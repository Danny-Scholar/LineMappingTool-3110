import java.util.List;

public class MatchedResult {
    public List<MatchedLine> matchedLines;

    public MatchedResult(List<MatchedLine> matchedLines) {
        this.matchedLines = matchedLines;
    }
}
