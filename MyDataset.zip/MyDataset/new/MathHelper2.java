public class MathHelper2 {

    public int powerOfTwo(int number) {
        return number * number;
    }

    public int powerOfThree(int number) {
        return number * number * number;
    }
}