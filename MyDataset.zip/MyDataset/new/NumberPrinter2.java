public class NumberPrinter2 {

    public void printNumbers() {
        int i = 1;
        while (i <= 5) {
            System.out.println("Number: " + i);
            i++;
        }
    }
}