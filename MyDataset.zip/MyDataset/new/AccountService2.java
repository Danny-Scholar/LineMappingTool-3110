public class AccountService2 {

    public void addFunds(double amt) {
        System.out.println("Added: $" + amt);
    }

    public void removeFunds(double amt) {
        System.out.println("Removed: $" + amt);
    }

    public void viewBalance() {
        System.out.println("Viewing balance.");
    }
}