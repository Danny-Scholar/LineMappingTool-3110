public class CounterIncrementer2 {

    public int addOne(int number) {
        int result = number;
        result++;
        return result;
    }
}