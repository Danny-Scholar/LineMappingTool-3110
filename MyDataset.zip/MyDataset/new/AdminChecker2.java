public class AdminChecker2 {

    public boolean isAdministrator(String r) {
        return "admin".equals(r);
    }
}