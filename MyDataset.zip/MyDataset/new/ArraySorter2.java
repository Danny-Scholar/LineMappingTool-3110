import java.util.Arrays;

public class ArraySorter2 {

    public void arrange(int[] data) {
        Arrays.sort(data);
    }
}