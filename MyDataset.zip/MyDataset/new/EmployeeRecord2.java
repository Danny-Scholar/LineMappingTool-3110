public class EmployeeRecord2 {

    public void printEmployeeDetails(String employeeName, int employeeId) {
        System.out.println("Name: " + employeeName + ", ID: " + employeeId);
    }
}