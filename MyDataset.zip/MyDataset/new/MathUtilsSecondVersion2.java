public class MathUtilsSecondVersion2 {

    public int getSquare(int number) {
        return multiply(number, number);
    }

    private int multiply(int a, int b) {
        return a * b;
    }
}