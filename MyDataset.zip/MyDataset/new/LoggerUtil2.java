public class LoggerUtil2 {

    public void logInfo(String msg) {
        System.out.println("INFO: " + msg);
    }

    public void logWarning(String msg) {
        System.out.println("WARNING: " + msg);
    }

    public void logError(String msg) {
        System.out.println("ERROR: " + msg);
    }
}