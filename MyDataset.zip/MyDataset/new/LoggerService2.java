public class LoggerService2 {

    public void writeLog(String message) {
        System.out.println(message);
    }
}