public class MathUtilsSecondVersion1 {

    public int square(int x) {
        return x * x;
    }
}