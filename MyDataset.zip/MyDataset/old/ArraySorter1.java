import java.util.Arrays;

public class ArraySorter1 {

    public void sortArray(int[] numbers) {
        Arrays.sort(numbers);
    }
}
