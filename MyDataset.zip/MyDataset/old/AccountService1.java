public class AccountService1 {

    public void deposit(double amount) {
        System.out.println("Deposited: $" + amount);
    }

    public void withdraw(double amount) {
        System.out.println("Withdrawn: $" + amount);
    }

    public void checkBalance() {
        System.out.println("Balance checked.");
    }
}