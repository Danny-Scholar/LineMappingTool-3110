public class EmployeeRecord1 {

    public void displayEmployee(String name, int id) {
        System.out.println("Name: " + name + ", ID: " + id);
    }
}