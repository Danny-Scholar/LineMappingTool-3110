public class MathHelper1 {

    public int square(int x) {
        return x * x;
    }

    public int cube(int x) {
        return x * x * x;
    }
}