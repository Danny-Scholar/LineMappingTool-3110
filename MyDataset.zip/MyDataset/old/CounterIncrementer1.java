public class CounterIncrementer1 {

    public int increment(int value) {
        return value + 1;
    }
}