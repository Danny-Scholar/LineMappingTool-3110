public class LoggerService1 {

    public void log(String msg) {
        System.out.println(msg);
    }
}